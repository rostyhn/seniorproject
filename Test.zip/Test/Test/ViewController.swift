//
//  ViewController.swift
//  Test
//
//  Created by Shah, Hiral N on 9/19/19.
//  Copyright © 2019 Shah, Hiral N. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var Start: UIButton!
    
    @IBAction func start_procedure(_ sender: Any) {
        performSegue(withIdentifier: "Start", sender:self)
    }
    
    @IBAction func About(_ sender: Any) {
        performSegue(withIdentifier: "About", sender: self)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }

    
    
}

